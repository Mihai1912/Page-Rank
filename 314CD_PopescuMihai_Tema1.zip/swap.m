function [A , B] = swap(B , A)
endfunction